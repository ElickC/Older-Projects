#ifndef LFSR_HPP_
#define LFSR_HPP_

#include <iostream>
#include <string>



class LFSR {
 private:
	int length;
	int tap;
	std::string _data;
	
 public:

	LFSR(std::string seed, int t);
	int step(); 
	int generate(int k);
	friend std::ostream& operator << (std::ostream& out, LFSR& lfsr);
};

#endif
